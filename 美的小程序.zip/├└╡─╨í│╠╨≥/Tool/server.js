var hostUrl = 'https://happyhn.gdtengnan.com';
//var hostUrl = 'http://hainanhuanle.com';
var serverUrl = hostUrl+'/index.php/Home';
function wxGet(url, data, func, func2) {
  var setting = {};
  if (url.indexOf('http://') !== 0 || url.indexOf('https://') !== 0) {
    url = serverUrl + url;
  }
  setting.url = url;
  if (typeof data == 'object') {
    setting.data = data;
  }
  setting.success = func;
  wx.request(setting)
}
function wxPost(url, data, func) {
  wx.showLoading({
    title: '加载中',
    mask:true
  })
  var setting = {};
  if (url.indexOf('http://') !== 0) {
    url = serverUrl + url;
  }
  setting.url = url;
  setting.method = 'POST';
  setting.header = { 'content-type': 'application/x-www-form-urlencoded'};
  if (typeof data == 'object') {
    setting.data = data;
  }
  setting.success = function (res) {
    func(res)
    wx.hideLoading();
  };
  // setting.fail = func2;
  wx.request(setting);
}

function style(str=''){
  var barname = '';
  if(str!=''){
    barname = str;
  }else{
    
  }
  var store = wx.getStorageSync('siteInfo').name;
  if(store){
    wx.setNavigationBarTitle({
      title: store,
    })
  }
}

module.exports = {
  hostUrl : hostUrl , wxGet : wxGet , wxPost : wxPost , style : style
}

