// pages/index/index.js
var server = require('../../Tool/server.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    show: true,
    first: true,
    auth: true
  },
  judgeFirst:function(){
    var first = this.data.first;
    if (first){
      this.setData({
        show:true
      })
    }else{
      wx.navigateTo({
        url: '',
        
      })
    }
  },
  cancelShow:function(){
    this.setData({
      show: false
    })
  },
  confirm:function(){
    wx.navigateTo({
      url: '../poster/poster',
      
    })
  },
  navigatorToHelper:function(){
    wx.navigateToMiniProgram({
      appId: '',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  getUserInfo: function (res) {
    console.log(res)
    var that = this;

    if (res.detail.errMsg == 'getUserInfo:ok') {
      that.setData({ auth: true });
      that.login();
    } else {
      that.setData({ auth: false });
    }
  },

  // 用户授权
  login: function () {
    console.log(222)
    var that = this;

    wx.login({
      success: function (res) {

        if (res.code) {
          console.log(res.code);
          var code = res.code;
          wx.getUserInfo({
            success: function (res) {
              wx.showLoading({
                title: "正在获取..",
                mask: true,
              });
              wx.setStorageSync("userinfo", res.userInfo);
              server.wxPost('/UserInfo/sendCode', {
                code: code
              }, function (res) {

                wx.hideLoading();
                wx.showTabBar({
                  animation: true,
                })
                console.log(res);

                console.log(res.data.openid);
                wx.setStorageSync("openid", res.data.openid);
                console.log(res.data.openid)

                that.register(res.data.openid);
              });
            }
          });
        }
      }
    });
  },

  register: function (openid) {
    var app = this;
    var openId = openid ? openid : wx.getStorageSync("openid");
    // var openId = 
    console.log(openId);
    var userInfo = wx.getStorageSync("userinfo");
    console.log(userInfo);
    var gender = userInfo.gender;
    console.log(gender);
    var nick_name = userInfo.nickName;
    console.log(nick_name);
    var avatarUrl = userInfo.avatarUrl;
    console.log(avatarUrl);
    server.wxPost('/UserInfo/register', {
      openid: openId,
      avatar: avatarUrl,
      nick_name: nick_name,
      sex: gender,
    }, function (res) {
      console.log(res);
    });
  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})