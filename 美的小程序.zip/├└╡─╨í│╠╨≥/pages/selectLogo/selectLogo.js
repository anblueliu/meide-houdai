Page({

  /**
   * 页面的初始数据
   */
  data: {
    selected: 0,
    imgs:[]
  },
  selectLogo: function (e) {
    this.setData({
      selected: e.currentTarget.dataset.id
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  //选择图片
  chooseimage: function () {
    var that = this;

    wx.chooseImage({
      count: 9, // 最多可以选择的图片张数，默认1
      sizeType: ['original', 'compressed'], // original 原图，compressed 压缩图，默认二者都有
      sourceType: ['album', 'camera'], // album 从相册选图，camera 使用相机，默认二者都有
      success: function (res) {
        var imgsrc = res.tempFilePaths;//这里是选好的图片的地址，是一个数组
        console.log(imgsrc)
        //触发图片上传
        for (var i = 0; i < imgsrc.length; i++) {
          that.uploadimg(imgsrc[i]); 
        }
      },
      fail: function () {
        // fail
      },
      complete: function () {
        // complete
      }
    })
  },
  // 这里触发图片上传的方法
  uploadimg: function (pics) {
    
    // 请求头类型
    var self = this;
    var imgs = this.data.imgs
    wx.uploadFile({
      // 渲染时换路劲
      url: 'https://sx.wwgxz.com/index.php/api/System/upload', //开发者服务器
      filePath: pics, //上传资源路径
      name: 'null', //服务器需要的key
      formData: {
        // 'url': localhostFilePath
      },
      header: {
        'content-type': 'multipart/form-data'//请求头
      },
      success: function (res) {
        wx.showToast({
          title: '上传成功',
          // icon: 'none'
        })
        var success_info = JSON.parse(res.data);
        imgs.push(success_info.data[0]);
        self.setData({
          imgs: imgs
        })
        console.log('imgs',imgs);
        
      },
      fail: function (res) {
        wx.showToast({
          title: res.data.msg,
          icon: 'none'
        })
      },
      complete: function (res) {
        // wx.showToast({
        //   title: res.data.msg,
        //   // icon: 'none'
        // })
      }

    });
  },
})