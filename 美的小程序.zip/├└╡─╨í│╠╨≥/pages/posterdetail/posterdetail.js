// pages/posterdetail/posterdetail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 字体包组
    font_family_list: [{
      Chinese: '默认字体',
      English: 'MR'
    }, {
      Chinese: '苹方',
      English: 'PC'
    }, {
      Chinese: '等线',
      English: 'DX'
    }, {
      Chinese: '微软雅黑',
      English: 'WRYH'
    }, {
      Chinese: '方正兰亭',
      English: 'FZLT'
    }, {
      Chinese: '方正兰亭',
      English: 'FZLT'
    }],
    // 选中字体包组的下标
    font_family_active: 0,
    // 颜色组
    color_list: ['#ffffff', '#949494', '#414141', '#000000', '#ff0048', '#b00085', '#6000ff', '#0054ff', '#00c0ff', '#00ff48', '#ffe400', '#00c0ff', '#00ff48', '#ffe400'],
    // 字体大小
    slider_value: 12,
    // logo宽
    logo_width: 175,
    // logo高
    logo_height: 62,
    // logo距左边距离
    logo_left: 231,
    // logo距顶部距离
    logo_top: 21,
    // active:0(未选中)，active:1(选中logo)，active>1(选中素材)，active:-1(选中字体)
    active: 0,
    move: 0,
    // 字段导航下标
    font_type: 0,
    // 选中字段组下标
    font_item: 0,
    // 字段组
    font_list: [{
      detail: "做食材好管家，有五合一保鲜123132",
      width: 400,
      height: 100,
      top: 0,
      left: 100,
      font_size: 20,
      color: "#fff",
      font_family: 'pc',
      text_align: 'left'
    }, {
      detail: "做食材好管家，有五合一保鲜做食材好管家，有五合一保鲜231231",
      width: 400,
      height: 100,
      top: 100,
      left: 100,
      font_size: 20,
      color: "#fff",
      font_family: 'WRYH',
      text_align: 'left'
    }],
    //是否展示logo 
    showlogo: true,
    // 素材图片组
    imagesList: [{
      src: '../../images/index-icon04.png',
      width: 100,
      height: 100,
      top: 100,
      left: 100
    }, {
      src: '../../images/index-icon04.png',
      width: 100,
      height: 100,
      top: 100,
      left: 100
    }],
    // 点击提交海报  (成功为1，失败为2)
    submitResult: 1,
    //点击提交海报提示  （提交成功为1，失败为2）
    showTips: 0,
  },
  //确定或者保存按钮
  keep: function() {
    this.setData({
      active: 0,
      move: 0,
      font_type: 0,
      font_item: 0,
    })
  },
  //选择字体 （字体包名要与字体英文名一致）
  selectFontFamily: function(e) {
    console.log(11111111)
    var font_list = this.data.font_list;
    var font_item = this.data.font_item;
    font_list[font_item].font_family = e.currentTarget.dataset.family;
    wx.loadFontFace({
      family: e.currentTarget.dataset.family,
      source: 'url("https://sungd.github.io/Pacifico.ttf")', //对应字体包路劲
      // success: console.log
    })
    this.setData({
      font_list: font_list,
      font_family_active: e.currentTarget.dataset.id
    })
  },


  //选择字体颜色
  selectFontColor: function(e) {
    var font_list = this.data.font_list;
    var font_item = this.data.font_item;
    font_list[font_item].color = e.currentTarget.dataset.color;
    this.setData({
      font_list: font_list
    })
  },
  //字体居左居右
  textAlign: function(e) {
    var font_list = this.data.font_list;
    var font_item = this.data.font_item;
    font_list[font_item].text_align = e.currentTarget.dataset.id;
    this.setData({
      font_list: font_list
    })
  },
  //选择编辑字段导航
  FontType: function(e) {
    this.setData({
      font_type: e.currentTarget.dataset.id
    })

  },
  // 获取logo宽高
  logoLoad: function(e) {
    this.setData({
      logo_width: e.detail.width,
      logo_height: e.detail.height
    })
  },
  // 点击选择图片
  logoActive: function(e) {
    this.setData({
      active: e.currentTarget.dataset.id,
      move: e.currentTarget.dataset.id,
      font_type: 0,
      showTips: 0
    })

  },
  // 获取字段一开始的位置
  movestartfont: function(e) {
    var font_list = this.data.font_list;
    this.setData({
      active: -1,
      font_item: e.currentTarget.dataset.id,
      slider_value: font_list[e.currentTarget.dataset.id].font_size,
      showTips: 0

    })
  },
  // 获取logo一开始的位置
  movestart: function(e) {
    this.setData({
      active: e.currentTarget.dataset.id,
      move: e.currentTarget.dataset.id,
      font_type: 0,
      showTips: 0

    })
  },
  // 移动logo
  moveLogo: function(e) {
    var move = this.data.move;
    var logo_width = this.data.logo_width / 4;
    var logo_height = this.data.logo_height / 4;
    var self = this;
    if (move == e.currentTarget.dataset.id) {
      self.setData({
        logo_left: e.touches[0].clientX - logo_width,
        logo_top: e.touches[0].clientY - logo_height
      })
    }
  },
  // 移动素材图片
  moveImages: function(e) {
    var move = this.data.move;
    var imagesList = this.data.imagesList;

    var width = imagesList[e.currentTarget.dataset.id - 2].width / 4;
    var height = imagesList[e.currentTarget.dataset.id - 2].height / 4;
    var self = this;
    if (move == e.currentTarget.dataset.id) {
      imagesList[e.currentTarget.dataset.id - 2].left = e.touches[0].clientX - width;
      imagesList[e.currentTarget.dataset.id - 2].top = e.touches[0].clientY - height;
      self.setData({
        imagesList: imagesList
      })
    }
  },
  // 移动字段
  moveFont: function(e) {
    var font_item = this.data.font_item;
    var font_list = this.data.font_list;
    var width = font_list[e.currentTarget.dataset.id].width / 4;
    var height = font_list[e.currentTarget.dataset.id].height / 4;
    var self = this;
    if (font_item == e.currentTarget.dataset.id) {
      font_list[e.currentTarget.dataset.id].left = e.touches[0].clientX - width;
      font_list[e.currentTarget.dataset.id].top = e.touches[0].clientY - height;
      self.setData({
        font_list: font_list
      })
    }
  },
  // 获取logo一开始的位置
  changeSizeStart: function(e) {
    this.setData({
      logo_x: e.touches[0].clientX,
      logo_y: e.touches[0].clientY
    })
  },
  // 获取素材图片一开始的位置
  changeSizeStartImages: function(e) {
    this.setData({
      images_x: e.touches[0].clientX,
      images_y: e.touches[0].clientY
    })


  },
  // 获取字段一开始的位置
  changeSizeStartFont: function(e) {
    this.setData({
      font_x: e.touches[0].clientX,
      font_y: e.touches[0].clientY
    })
  },
  // 改变logo大小
  changeSize: function(e) {
    var width_change = e.touches[0].clientX - this.data.logo_x;
    var height_change = e.touches[0].clientY - this.data.logo_y;
    var width = this.data.logo_width + width_change * 2;
    var height = this.data.logo_height + height_change * 2;
    var self = this;
    if (width > 40 && height > 40) {
      self.setData({
        logo_width: width,
        logo_height: height,
      })
    }
    self.setData({
      logo_x: e.touches[0].clientX,
      logo_y: e.touches[0].clientY
    })
  },

  // 改变字段大小
  changeSizeFont: function(e) {
    var font_list = this.data.font_list;
    var i = e.currentTarget.dataset.id;
    var width_change = e.touches[0].clientX - this.data.font_x;
    var height_change = e.touches[0].clientY - this.data.font_y;
    var width = font_list[i].width + width_change * 2;
    var height = font_list[i].height + height_change * 2;
    font_list[i].width = width;
    font_list[i].height = height;
    var self = this;
    if (width > 40 && height > 40) {
      self.setData({
        font_list: font_list
      })
    }
    self.setData({
      font_x: e.touches[0].clientX,
      font_y: e.touches[0].clientY
    })
  },

  // 改变素材图片大小
  changeSizeImages: function(e) {
    var imagesList = this.data.imagesList;
    var i = e.currentTarget.dataset.id;
    var width_change = e.touches[0].clientX - this.data.images_x;
    var height_change = e.touches[0].clientY - this.data.images_y;
    var width = imagesList[i].width + width_change * 2;
    var height = imagesList[i].height + height_change * 2;
    imagesList[i].width = width;
    imagesList[i].height = height;
    var self = this;
    if (width > 80 && height > 80) {
      self.setData({
        imagesList: imagesList
      })
    }
    self.setData({
      images_x: e.touches[0].clientX,
      images_y: e.touches[0].clientY
    })
  },
  // 删除logo
  cancelLogo: function() {
    this.setData({
      showlogo: false
    })
  },
  // 删除图片
  cancelImage: function(e) {
    var imagesList = this.data.imagesList;
    imagesList.splice(e.currentTarget.dataset.id, 1)
    this.setData({
      imagesList: imagesList
    })
  },

  // 删除字段
  cancelFont: function(e) {
    var font_list = this.data.font_list;
    font_list.splice(e.currentTarget.dataset.id, 1)
    this.setData({
      font_list: font_list,
      active: 0
    })
  },
  //获取素材图片大小
  imagesLoad: function(e) {
    var imagesList = this.data.imagesList;
    imagesList[e.currentTarget.dataset.id].width = e.detail.width;
    imagesList[e.currentTarget.dataset.id].height = e.detail.height;
    this.setData({
      imagesList: imagesList
    })

  },
  //选择字体大小
  selectFont: function(e) {
    var font_item = this.data.font_item;
    var font_list = this.data.font_list;
    font_list[font_item].font_size = e.detail.value
    this.setData({
      font_list: font_list
    })
  },
  //增大字体
  addFontSize: function() {
    var font_item = this.data.font_item;
    var font_list = this.data.font_list;
    if (font_list[font_item].font_size < 96) {
      font_list[font_item].font_size = font_list[font_item].font_size + 5
    }
    this.setData({
      font_list: font_list,
      slider_value: font_list[font_item].font_size
    })
  },
  //缩小字体
  subFontSize: function() {
    var font_item = this.data.font_item;
    var font_list = this.data.font_list;
    if (font_list[font_item].font_size > 24) {
      font_list[font_item].font_size = font_list[font_item].font_size - 5
    }
    this.setData({
      font_list: font_list,
      slider_value: font_list[font_item].font_size
    })
  },

  // 加载字段字体包 （字体包名要与字体英文名一致）
  loadFont: function() {
    var font_list = this.data.font_list;
    for (var i = 0; i < font_list.length; i++) {
      wx.loadFontFace({
        family: font_list[i].font_family,
        source: 'url("https://sungd.github.io/Pacifico.ttf")', //对应字体包路劲
        success: console.log
      })
    }
  },
  //提交海报
  submitPoster: function() {
    var submitResult = this.data.submitResult;
    if (submitResult == 1) {
      this.setData({
        showTips: 1
      })
    } else if (submitResult == 2) {
      this.setData({
        showTips: 2
      })
    }


  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.loadFont();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})